import { useState } from 'react';
import { useTranslation } from 'react-i18next';

export default function Wizard({ onComplete }) {
  const { t } = useTranslation();
  const [mode, setMode] = useState('guided'); // 'guided' or 'prompt'
  const [step, setStep] = useState(0);
  const [promptText, setPromptText] = useState('');
  const [preferences, setPreferences] = useState({
    homeType: '',
    storeys: '',
    budget: '',
    vastu: '',
    rooms: [],
    kitchenStyle: '',
    style: '',
    colorPalette: '',
    facing: '',
    flooring: '',
    specialRequirements: []
  });

  const questions = [
    { id: 'homeType', icon: '🏠', isMulti: false },
    { id: 'storeys', icon: '🏢', isMulti: false },
    { id: 'budget', icon: '💰', isMulti: false },
    { id: 'vastu', icon: '🧭', isMulti: false },
    { id: 'rooms', icon: '🛏️', isMulti: true },
    { id: 'kitchenStyle', icon: '🍳', isMulti: false },
    { id: 'style', icon: '✨', isMulti: false },
    { id: 'colorPalette', icon: '🎨', isMulti: false },
    { id: 'facing', icon: '☀️', isMulti: false },
    { id: 'flooring', icon: '🪵', isMulti: false },
    { id: 'specialRequirements', icon: '♿', isMulti: true },
  ];

  const currentQ = questions[step];

  const getQuestionTitle = (qId) => {
    const titles = {
      homeType: "What type of home are you planning?",
      storeys: "How many storeys/floors do you want?",
      budget: "What's your budget?",
      vastu: "Do you want Vastu compliance?",
      rooms: "Which rooms do you need?",
      kitchenStyle: "What kitchen style do you prefer?",
      style: "Preferred interior style?",
      colorPalette: "What color palette do you prefer?",
      facing: "Main facing direction?",
      flooring: "What flooring do you prefer?",
      specialRequirements: "Any special requirements?"
    };
    return t(`wizard.questions.${qId}`, titles[qId]);
  };

  const getQuestionSubtitle = (qId) => {
    const subtitles = {
      homeType: "Answer a few questions to get your personalized floor plan",
      storeys: "Select single storey, stacked rental floors, or an apartment",
      budget: "Select a comfortable budget range for construction",
      vastu: "Vastu principles will guide the orientation of key areas",
      rooms: "Choose all spaces you want included in the layout",
      kitchenStyle: "This shapes your kitchen layout in 3D",
      style: "This defines the visual theme of your home interior",
      colorPalette: "This guides wall colors and furniture choices",
      facing: "Main entrance orientation for sunlight and ventilation",
      flooring: "Applied across all rooms in your 3D model",
      specialRequirements: "We'll factor these into your design"
    };
    return t(`wizard.subtitles.${qId}`, subtitles[qId]);
  };

  const getQuestionOptions = (qId) => {
    const fallbacks = {
      homeType: ["1BHK", "2BHK", "3BHK", "Villa", "Studio"],
      storeys: ["Single Storey", "2 Storeys (Owner + Rental)", "3 Storeys (Multi-Family/Rent)", "Apartment Flat"],
      budget: ["Under ₹5L", "₹5L–₹15L", "₹15L–₹30L", "₹30L+"],
      vastu: ["Yes, strictly", "Preferred", "No"],
      rooms: ["Pooja Room", "Open Kitchen", "Study Room", "Servant Room", "Balcony", "Home Office", "Home Gym", "Guest Room"],
      kitchenStyle: ["Open Kitchen", "Closed Kitchen", "L-Shaped", "Parallel / Galley", "Island Kitchen"],
      style: ["Modern", "Traditional Indian", "Minimalist", "Royal/Heritage"],
      colorPalette: ["Warm (beige, terracotta)", "Cool (white, grey)", "Bold & Vibrant", "Earthy & Natural", "Soft Pastel"],
      facing: ["East", "West", "North", "South", "Don't know"],
      flooring: ["Marble", "Vitrified Tiles", "Wooden Laminate", "Granite", "No preference"],
      specialRequirements: ["Wheelchair accessible", "Senior-friendly", "Pet-friendly", "Work-from-home setup", "None of the above"]
    };
    const translated = t(`wizard.options.${qId}`, { returnObjects: true });
    return Array.isArray(translated) ? translated : fallbacks[qId];
  };

  const getOptionIcon = (questionId, index, defaultIcon) => {
    const icons = {
      homeType: ["🚪", "🏠", "🏡", "🏰", "🏢"],
      storeys: ["🏡", "🏢", "🏘️", "🏬"],
      budget: ["📉", "💵", "💰", "💎"],
      vastu: ["😇", "👍", "❌"],
      rooms: ["🪔", "🍳", "📚", "🧹", "🌅", "💻", "🏋️", "🛏️"],
      kitchenStyle: ["🔓", "🚪", "📐", "↔️", "🏝️"],
      style: ["✨", "🕌", "🎋", "👑"],
      colorPalette: ["🌅", "❄️", "🎨", "🌳", "🌸"],
      facing: ["🌅", "🌇", "🧭", "☀️", "🤷"],
      flooring: ["⬜", "🔲", "🪵", "🪨", "🎲"],
      specialRequirements: ["♿", "👴", "🐾", "💻", "✅"]
    };
    if (icons[questionId] && icons[questionId][index]) {
      return icons[questionId][index];
    }
    return defaultIcon;
  };

  const options = getQuestionOptions(currentQ.id);

  const aiPresets = [
    "3BHK traditional South Indian home with a small central pooja mandir and a wide balcony",
    "Compact 2BHK modern apartment with modular kitchen and open living room, North-East facing",
    "Spacious 3BHK heritage villa styling with large living area, separate study room, strictly Vastu compliant",
    "Minimalist 1BHK studio apartment optimized for budget and remote-work setup",
    "Royal Rajasthani style 4BHK home with grand master bedroom, open-top courtyard, and servant quarters"
  ];

  const handleSelect = (opt, index) => {
    if (currentQ.isMulti) {
      const current = preferences[currentQ.id] || [];
      let next;
      
      if (currentQ.id === 'specialRequirements') {
        if (index === 4) { // None of the above
          next = [opt];
        } else {
          // Deselect None of the above if another option is chosen
          const noneOptionValue = options[4];
          const filtered = current.filter(x => x !== noneOptionValue);
          next = filtered.includes(opt) 
            ? filtered.filter(x => x !== opt) 
            : [...filtered, opt];
        }
      } else {
        next = current.includes(opt) 
          ? current.filter(x => x !== opt) 
          : [...current, opt];
      }
      setPreferences({ ...preferences, [currentQ.id]: next });
    } else {
      setPreferences({ ...preferences, [currentQ.id]: opt });
      if (step < questions.length - 1) {
        setTimeout(() => setStep(step + 1), 300);
      }
    }
  };

  const isSelected = (opt) => {
    if (currentQ.isMulti) {
      return (preferences[currentQ.id] || []).includes(opt);
    }
    return preferences[currentQ.id] === opt;
  };

  const isNextDisabled = () => {
    const val = preferences[currentQ.id];
    if (currentQ.isMulti) {
      return !val || val.length === 0;
    }
    return !val;
  };

  const handleNext = () => {
    if (step < questions.length - 1) setStep(step + 1);
    else onComplete(preferences);
  };

  const handleBack = () => {
    if (step > 0) setStep(step - 1);
  };

  const handlePromptSubmit = () => {
    if (!promptText.trim()) return;
    onComplete({ description: promptText, isAI: true });
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: '#06070d',
      zIndex: 1000,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      overflowY: 'auto',
      padding: '90px 1.5rem 1.5rem 1.5rem',
      fontFamily: 'var(--font-sans)'
    }}>
      
      {/* Edge-to-edge Header HUD */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: '64px',
        background: '#0a0b12',
        borderBottom: '1px solid rgba(255, 255, 255, 0.05)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '0 2rem',
        zIndex: 1010
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '1.35rem', animation: 'flame 1.5s ease infinite' }}>🔥</span>
          <span style={{ 
            fontFamily: 'var(--font-display)', 
            fontWeight: '800', 
            fontSize: '1.25rem', 
            background: 'linear-gradient(135deg, var(--color-fire-1), var(--color-fire-2))',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            letterSpacing: '0.5px' 
          }}>
            Agni AI
          </span>
        </div>
        
        {mode === 'guided' && (
          <div style={{ 
            color: 'var(--color-text-secondary)', 
            fontSize: '0.8rem', 
            fontWeight: '600',
            fontFamily: 'var(--font-sans)',
            opacity: 0.8
          }}>
            Question {step + 1} of {questions.length}
          </div>
        )}
        
        <button 
          onClick={() => setMode(mode === 'guided' ? 'prompt' : 'guided')}
          style={{ 
            background: 'rgba(255, 255, 255, 0.03)', 
            border: '1px solid rgba(255, 255, 255, 0.08)', 
            borderRadius: '50%', 
            width: '38px', 
            height: '38px', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center', 
            cursor: 'pointer',
            color: '#ec4899',
            fontSize: '1.1rem',
            boxShadow: '0 0 10px rgba(236,72,153,0.1)',
            transition: 'all 0.2s ease'
          }} 
          title={mode === 'guided' ? "Switch to AI Prompt Console" : "Switch to Guided Questionnaire"}
        >
          🪄
        </button>
      </div>

      {/* Horizontal Progress Bar Track */}
      {mode === 'guided' && (
        <div style={{
          position: 'absolute',
          top: '64px',
          left: 0,
          right: 0,
          height: '4px',
          background: 'rgba(255,255,255,0.03)',
          zIndex: 1010
        }}>
          <div style={{
            width: `${((step + 1) / questions.length) * 100}%`,
            height: '100%',
            background: 'linear-gradient(90deg, var(--color-fire-1), var(--color-fire-2))',
            boxShadow: '0 0 12px rgba(236, 72, 153, 0.65)',
            transition: 'width 0.4s cubic-bezier(0.16, 1, 0.3, 1)'
          }} />
        </div>
      )}

      {/* Centered wizard container card */}
      <div className="card animate-fade-up" style={{ 
        maxWidth: '800px', 
        width: '100%',
        padding: '2.5rem',
        background: 'rgba(16, 17, 30, 0.95)',
        border: '1px solid rgba(255, 255, 255, 0.07)',
        borderRadius: '24px',
        boxShadow: '0 20px 50px rgba(0,0,0,0.5)',
        transition: 'transform 0.3s ease'
      }}>
        {/* Mode Selector Tabs */}
        <div className="flex gap-2 mb-4 p-1 rounded-full" style={{ background: 'var(--color-surface-2)', border: '1px solid var(--color-border-subtle)', maxWidth: 'fit-content', margin: '0 auto 2.5rem auto' }}>
          <button 
            className="btn btn-sm" 
            onClick={() => setMode('guided')}
            style={{ 
              background: mode === 'guided' ? 'linear-gradient(135deg, var(--color-fire-1), var(--color-fire-2))' : 'transparent',
              color: mode === 'guided' ? 'white' : 'var(--color-text-secondary)',
              boxShadow: mode === 'guided' ? '0 2px 10px rgba(236,72,153,0.3)' : 'none',
              borderRadius: '9999px',
              border: 'none',
              cursor: 'pointer'
            }}
          >
            🧭 Guided Questionnaire
          </button>
          <button 
            className="btn btn-sm" 
            onClick={() => setMode('prompt')}
            style={{ 
              background: mode === 'prompt' ? 'linear-gradient(135deg, var(--color-fire-1), var(--color-fire-2))' : 'transparent',
              color: mode === 'prompt' ? 'white' : 'var(--color-text-secondary)',
              boxShadow: mode === 'prompt' ? '0 2px 10px rgba(236,72,153,0.3)' : 'none',
              borderRadius: '9999px',
              border: 'none',
              cursor: 'pointer'
            }}
          >
            ✨ AI Prompt Console
          </button>
        </div>

        {mode === 'guided' ? (
          <div className="animate-fade-in">
            <div style={{ marginBottom: '1.5rem' }}>
              <div style={{
                color: 'var(--color-fire-1)',
                fontSize: '0.75rem',
                fontWeight: '800',
                letterSpacing: '1.5px',
                textTransform: 'uppercase',
                marginBottom: '0.5rem',
                fontFamily: 'var(--font-display)'
              }}>
                STEP {step + 1} OF {questions.length}
              </div>
              <h2 style={{ fontSize: '1.85rem', fontWeight: '800', margin: '0 0 0.5rem 0', color: 'white', lineHeight: '1.25', fontFamily: 'var(--font-display)' }}>
                {getQuestionTitle(currentQ.id)}
              </h2>
              <p className="text-secondary" style={{ fontSize: '0.95rem', color: 'var(--color-text-secondary)', margin: 0 }}>
                {getQuestionSubtitle(currentQ.id)}
              </p>
              
              {/* Green/Teal instruction for multi-select */}
              {currentQ.isMulti && (
                <div style={{
                  color: '#4ecdc4',
                  fontSize: '0.825rem',
                  fontWeight: '700',
                  marginTop: '0.75rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px'
                }}>
                  <span style={{ fontSize: '0.5rem' }}>●</span> Select all that apply
                </div>
              )}
            </div>

            {/* Options Grid */}
            <div className="grid" style={{ 
              gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
              gap: '14px',
              margin: '2.5rem 0'
            }}>
              {Array.isArray(options) && options.map((opt, i) => (
                <div 
                  key={i} 
                  className={`option-card ${isSelected(opt) ? 'selected' : ''}`}
                  onClick={() => handleSelect(opt, i)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '0.95rem 1.25rem',
                    background: isSelected(opt) ? 'rgba(236, 72, 153, 0.12)' : 'rgba(23, 23, 29, 0.45)',
                    border: isSelected(opt) 
                      ? '1px solid var(--color-fire-1)' 
                      : '1px solid rgba(255, 255, 255, 0.08)',
                    borderRadius: '14px',
                    cursor: 'pointer',
                    transition: 'all 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
                    minHeight: '62px',
                    boxShadow: isSelected(opt) 
                      ? '0 0 15px rgba(236, 72, 153, 0.25)' 
                      : '0 4px 12px rgba(0,0,0,0.15)',
                    transform: isSelected(opt) ? 'scale(1.02)' : 'scale(1)',
                    position: 'relative',
                    overflow: 'hidden',
                    justifyContent: 'flex-start',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => {
                    if (!isSelected(opt)) {
                      e.currentTarget.style.borderColor = 'rgba(236, 72, 153, 0.45)';
                      e.currentTarget.style.background = 'rgba(236, 72, 153, 0.06)';
                      e.currentTarget.style.transform = 'translateY(-2px)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isSelected(opt)) {
                      e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.08)';
                      e.currentTarget.style.background = 'rgba(23, 23, 29, 0.45)';
                      e.currentTarget.style.transform = 'translateY(0)';
                    }
                  }}
                >
                  <div className="icon" style={{ 
                    fontSize: '1.35rem', 
                    transform: isSelected(opt) ? 'scale(1.15)' : 'scale(1)', 
                    transition: 'transform 0.25s ease',
                    flexShrink: 0
                  }}>
                    {getOptionIcon(currentQ.id, i, currentQ.icon)}
                  </div>
                  <div className="label" style={{ 
                    color: isSelected(opt) ? 'white' : 'var(--color-text)', 
                    fontWeight: '600', 
                    fontSize: '0.95rem',
                    lineHeight: '1.3'
                  }}>
                    {opt}
                  </div>
                </div>
              ))}
            </div>

            {/* Navigation Buttons Row */}
            <div className="flex justify-between mt-4 pt-4" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
              <button 
                className="btn btn-ghost btn-sm" 
                onClick={handleBack} 
                disabled={step === 0}
                style={{
                  border: '1px solid rgba(255,255,255,0.08)',
                  background: 'transparent',
                  color: step === 0 ? 'rgba(255,255,255,0.2)' : 'var(--color-text-secondary)',
                  borderRadius: '9999px',
                  padding: '0.65rem 1.75rem',
                  fontSize: '0.875rem',
                  fontWeight: '600',
                  cursor: step === 0 ? 'not-allowed' : 'pointer',
                  transition: 'all 0.2s ease'
                }}
              >
                ← Back
              </button>
              
              <button 
                className="btn btn-primary btn-sm" 
                onClick={handleNext}
                disabled={isNextDisabled()}
                style={{
                  background: isNextDisabled() 
                    ? 'rgba(255, 255, 255, 0.03)' 
                    : 'linear-gradient(135deg, var(--color-fire-1), var(--color-fire-2))',
                  border: isNextDisabled() ? '1px solid rgba(255,255,255,0.05)' : 'none',
                  color: isNextDisabled() ? 'rgba(255,255,255,0.25)' : 'white',
                  boxShadow: isNextDisabled() ? 'none' : '0 4px 20px rgba(236, 72, 153, 0.35)',
                  borderRadius: '9999px',
                  padding: '0.65rem 2.25rem',
                  fontSize: '0.9rem',
                  fontWeight: '700',
                  cursor: isNextDisabled() ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  transition: 'all 0.2s ease'
                }}
              >
                {step === questions.length - 1 ? '🔥 Generate My Home' : 'Next →'}
              </button>
            </div>
          </div>
        ) : (
          <div className="animate-fade-in flex flex-col gap-4">
            <div className="text-center mb-2">
              <h2 className="display-md text-gradient" style={{ fontSize: '1.75rem', marginBottom: '0.5rem' }}>Describe your dream home</h2>
              <p className="text-sm text-secondary">Agni AI will draft a tailored, Vastu-compliant layout based on your text prompts.</p>
            </div>

            <textarea 
              className="input w-full" 
              rows="5"
              placeholder="Type in detail, e.g.: A 3BHK royal style home with a traditional central Pooja room, South-facing entrance, spacious kitchen with modular setup, and wooden wardrobes in bedroom..."
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              style={{
                resize: 'none',
                background: 'var(--color-surface-2)',
                border: '1px solid var(--color-border)',
                boxShadow: '0 0 20px rgba(236, 72, 153, 0.05)',
                padding: '1rem',
                borderRadius: '12px',
                fontFamily: 'inherit',
                lineHeight: '1.5'
              }}
            />

            <div>
              <div className="text-xs font-bold text-secondary mb-2 uppercase tracking-wide">💡 Or click a preset suggestion chip:</div>
              <div className="scroll-panel flex gap-2 pb-2" style={{ overflowX: 'auto', whiteSpace: 'nowrap', paddingRight: '8px' }}>
                {aiPresets.map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => setPromptText(preset)}
                    className="tag"
                    style={{
                      fontSize: '0.8rem',
                      padding: '0.4rem 0.9rem',
                      border: '1px solid rgba(236, 72, 153, 0.15)',
                      background: promptText === preset ? 'rgba(236, 72, 153, 0.12)' : 'var(--color-surface-2)',
                      color: promptText === preset ? 'var(--color-fire-1)' : 'var(--color-text-secondary)',
                      borderRadius: '9999px',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                      flexShrink: 0
                    }}
                  >
                    {preset.slice(0, 45)}...
                  </button>
                ))}
              </div>
            </div>

            <button 
              className="btn btn-primary w-full mt-2" 
              onClick={handlePromptSubmit}
              disabled={!promptText.trim()}
              style={{ 
                padding: '1rem', 
                fontSize: '1rem',
                display: 'flex',
                gap: '0.5rem',
                justifyContent: 'center',
                fontWeight: '700'
              }}
            >
              ✨ {t('wizard.generate')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

